var video;
var shutterButton;
var switchCameraButton;
var numberOfCameras = 0;
var currentFacingMode = 'user';

/**
 * Return a promise w/ the number of cameras of the device
 * - resolve w/ an integer larger than zero if successful
 *   and at least one camera is available
 * - resolve w/ zero if no cameras are attached or request
 *   is unsuccessful
 * - never rejects
 */
function getCameraCount() {
  return new Promise((resolve) => {
    let videoInCount = 0;

    navigator.mediaDevices
      .enumerateDevices()
      .then((devices) => {
        devices.forEach((device) => {
          if (device.kind === 'video') {
            device.kind = 'videoinput';
          }
          if (device.kind === 'videoinput') {
            videoInCount++;
            console.log('videocam: ' + device.label);
          }
        });
        resolve(videoInCount);
      }).catch((err) => {
        alert('Oops! An error has occured while enumerating the cameras of your device.');
        console.log(err.name + ': ' + err.message);
        resolve(0);
      });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  checkScreenOrientation();
  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia && navigator.mediaDevices
    .enumerateDevices) {
    navigator.mediaDevices
      .getUserMedia({
        audio: false,
        video: true,
      }).then((stream) => {
        stream.getTracks().forEach((track) => {
          track.stop();
        });
        getCameraCount().then((cameraCount) => {
          numberOfCameras = cameraCount;
          initCameraUI();
          initCameraStream();
          if (cameraCount > 2) {
            document.querySelector('#switchCameraButton').style.display = 'block';
          }
        });
      }).catch((error) => {
        if (error === 'PermissionDeniedError') {
          alert('Oops, permission denied. Please refresh and give permission.');
        }
        console.error('getUserMedia() error: ', error);
      });
  } else {
    alert('Sorry! Mobile camera is not supported by browser, or there is no camera detected/connected');
  }
});

function initCameraUI() {
  video = document.querySelector('#video');
  shutterButton = document.querySelector('#shutterButton');
  switchCameraButton = document.querySelector('#switchCameraButton');
  shutterButton.addEventListener('click', () => takeSnapshot());

  const newPhotoLink = document.querySelector('#seWrapperLink');
  newPhotoLink.addEventListener('click', () => {
    document.querySelector('#seWrapper').style.display = 'none';
    document.querySelector('#seWrapperCamera').style.display = 'block';
  });

  if (numberOfCameras > 1) {
    switchCameraButton.style.display = 'block';
    switchCameraButton.addEventListener('click', () => {
      currentFacingMode = currentFacingMode === 'environment' ? 'user' : 'environment';
      initCameraStream();
    });
  }

  window.addEventListener('orientationchange', () => {
    setTimeout(() => {
      checkScreenOrientation();
      window.scrollTo(0, 1);
    }, 1000);
  }, false);
}

function getScreenAngle() {
  return screen.orientation ? screen.orientation.angle : window.orientation;
}

function checkScreenOrientation() {
  const screenAngle = getScreenAngle();
  if (screenAngle !== 90 && screenAngle !== -90 && window.innerHeight >= window.innerWidth) {
    document.querySelector('.santa-container').classList.add('hidden');
    document.querySelector('#landscapeNote').classList.remove('hidden');
  } else {
    document.querySelector('.santa-container').classList.remove('hidden');
    document.querySelector('#landscapeNote').classList.add('hidden');
  }
  if (window.innerWidth <= 900) {
    const calculatedVideoWidth = document.querySelector('.santa-img > img').clientWidth !== 0 ? document.querySelector('.santa-img > img').clientWidth : window.outerHeight * (4/3);
    document.querySelector('#video').style.width = `${calculatedVideoWidth}px`;
  }
}

function initCameraStream() {
  if (window.stream) {
    window.stream.getTracks().forEach((track) => {
      console.log(track);
      track.stop();
    });
  }

  var constraints = {
    audio: false,
    video: {
      width: {
        ideal: 1280
      },
      height: {
        ideal: 720
      },
      facingMode: currentFacingMode,
    },
  };

  navigator.mediaDevices
    .getUserMedia(constraints)
    .then(handleSuccess)
    .catch(handleError);

  function handleSuccess(stream) {
    window.stream = stream; // make stream available to browser console
    video.srcObject = stream;

    if (currentFacingMode === 'user') {
      video.classList.add('flipped');
    } else {
      video.classList.remove('flipped');
    }

    if (constraints.video.facingMode) {
      if (constraints.video.facingMode === 'environment') {
        switchCameraButton.setAttribute('aria-pressed', true);
      } else {
        switchCameraButton.setAttribute('aria-pressed', false);
      }
    }

    const track = window.stream.getVideoTracks()[0];
    const settings = track.getSettings();
    str = JSON.stringify(settings, null, 4);
    console.log('settings ' + str);
  }

  function handleError(error) {
    console.error('getUserMedia() error: ', error);
  }
}

function takeSnapshot() {
  const canvas = document.createElement('canvas');
  canvas.height = video.videoHeight; // Use the maximum supported height of the camera
  canvas.width = Math.ceil(canvas.height * (4 / 3)); // Use such a width that 4:3 aspect ratio is achieved
  context = canvas.getContext('2d');

  takeVideoSnapshot(video, (4/3), currentFacingMode === 'user').then(croppedSnapshot => {
    context.drawImage(croppedSnapshot, 0, 0);
    const santaFrame = new Image();
    santaFrame.onload = () => {
      context.drawImage(santaFrame, 0, 0, canvas.width, canvas.height);
      document.querySelector('#seWrapper').style.display = 'block';
      document.querySelector('#seWrapperCamera').style.display = 'none';

      const downloadButton = document.querySelector('#seWrapperButton');
      downloadButton.addEventListener('click', () => {
        let eventLabel = 'Easter 2021';
        if (window.location.pathname.includes('westbrookmall')) {
          eventLabel += ' - Westbrook Mall';
        } else if (window.location.pathname.includes('marlboroughmall')) {
          eventLabel += ' - Marlborough Mall';
        } else {
          eventLabel += ' - main page';
        }
        ga('send', {
          hitType: 'event',
          eventCategory: 'Photo with EasterBunny',
          eventAction: 'Download',
          eventLabel: eventLabel
        });
        const link = document.createElement('a');
        link.download = 'picture_with_easterbunny.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
      });

      const finalSantaImage = document.querySelector('#seWrapperPhoto');
      finalSantaImage.src = canvas.toDataURL('image/png');
    };
    santaFrame.src = 'frame_full.png';
  });
}

/**
 * Crop an image using a specified aspect ratio (center crop)
 * @param {string} url Source image URL
 * @param {number} aspectRatio Target aspect ratio
 * @return {Promise<HTMLCanvasElement>} A Promise that resolves with the resulting image as a canvas element
 */
function takeVideoSnapshot(video, aspectRatio, flip = false) {
  return new Promise(resolve => {
    const inputWidth = video.videoWidth;
    const inputHeight = video.videoHeight;
    const inputImageAspectRatio = inputWidth / inputHeight;
    let outputWidth = inputWidth;
    let outputHeight = inputHeight;
    if (inputImageAspectRatio > aspectRatio) {
      outputWidth = inputHeight * aspectRatio;
    } else if (inputImageAspectRatio < aspectRatio) {
      outputHeight = inputWidth / aspectRatio;
    }
    const outputX = (outputWidth - inputWidth) * .5;
    const outputY = (outputHeight - inputHeight) * .5;
    const outputImage = document.createElement('canvas');

    outputImage.width = outputWidth;
    outputImage.height = outputHeight;

    const ctx = outputImage.getContext('2d');
    if (flip) {
      ctx.translate(outputImage.width, 0);
      ctx.scale(-1, 1);
    }
    ctx.drawImage(video, outputX, outputY);
    resolve(outputImage);
  });
}