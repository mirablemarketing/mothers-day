// Check for IE
const ua = window.navigator.userAgent;
const msie = ua.indexOf('MSIE ');
const trident = ua.indexOf('Trident/');
if (msie > 0 || trident > 0) {
  document.querySelector('#seWrapperIEMessage').style.display = 'block';
  document.querySelector('#seWrapperCamera').style.display = 'none';
}